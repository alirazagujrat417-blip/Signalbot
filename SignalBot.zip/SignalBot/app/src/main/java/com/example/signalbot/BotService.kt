package com.example.signalbot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

class BotService : Service() {
    // ---- Tuning: chart ka area (screen ka fraction). Apni screen ke hisaab se badlo ----
    private val chartTop = 0.18f
    private val chartBottom = 0.60f
    private val chartRight = 0.92f

    private val h = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private var w = 0
    private var hgt = 0

    private var logo: TextView? = null
    private var panel: LinearLayout? = null
    private var status: TextView? = null

    private var running = false
    private var tfSec = 60
    private var comp = 1
    private var buyX = -1f; private var buyY = -1f
    private var sellX = -1f; private var sellY = -1f
    private val tickRun = Runnable { tick() }

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        startFg()
        val code = i?.getIntExtra("code", 0) ?: 0
        @Suppress("DEPRECATION")
        val data: Intent? = i?.getParcelableExtra("data")
        if (data != null) {
            proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
            proj?.registerCallback(object : MediaProjection.Callback() {}, h)
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            setupCapture()
            showLogo()
        }
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("bot", "Bot", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "bot").setContentTitle("Signal Bot chal raha hai")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun setupCapture() {
        val dm = resources.displayMetrics
        w = dm.widthPixels; hgt = dm.heightPixels
        reader = ImageReader.newInstance(w, hgt, PixelFormat.RGBA_8888, 2)
        vd = proj?.createVirtualDisplay("cap", w, hgt, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
    }

    private fun lp(x: Int, y: Int) = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START; this.x = x; this.y = y }

    private fun showLogo() {
        logo = TextView(this).apply {
            text = "🤖"; textSize = 26f; gravity = Gravity.CENTER; setPadding(20, 10, 20, 10)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF1E3A8A.toInt()) }
            setOnClickListener {
                panel?.visibility = if (panel?.visibility == View.VISIBLE) View.GONE else View.VISIBLE
            }
        }
        wm.addView(logo, lp(0, 300))
        buildPanel()
    }

    private fun buildPanel() {
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(24, 24, 24, 24)
            setBackgroundColor(0xEE111827.toInt())
        }
        fun label(t: String) = p.addView(TextView(this).apply { text = t; setTextColor(Color.WHITE) })
        fun btn(t: String, f: () -> Unit) = p.addView(Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        })
        label("Compounding:")
        btn("1x") { comp = 1; say("Compounding 1x") }
        btn("2x") { comp = 2; say("Compounding 2x") }
        btn("3x") { comp = 3; say("Compounding 3x") }
        label("Timeframe:")
        btn("1 min") { tfSec = 60; say("TF 1m") }
        btn("2 min") { tfSec = 120; say("TF 2m") }
        btn("5 min") { tfSec = 300; say("TF 5m") }
        btn("Calibrate Buy/Sell") { calibrate() }
        btn("START / STOP") { toggle() }
        status = TextView(this).apply { text = "Taiyar"; setTextColor(Color.YELLOW) }
        p.addView(status)
        panel = p
        wm.addView(p, lp(120, 300))
    }

    private fun say(t: String) { status?.text = t }

    private fun calibrate() {
        panel?.visibility = View.GONE
        val hint = TextView(this).apply {
            text = "BUY button par tap karo"; textSize = 22f; setTextColor(Color.WHITE)
            setBackgroundColor(0xCC000000.toInt()); setPadding(24, 24, 24, 24)
        }
        val root = FrameLayout(this).apply { setBackgroundColor(0x22000000) }
        root.addView(hint, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        var step = 0
        root.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                if (step == 0) {
                    buyX = e.rawX; buyY = e.rawY; step = 1; hint.text = "Ab SELL button par tap karo"
                } else {
                    sellX = e.rawX; sellY = e.rawY
                    wm.removeView(root)
                    panel?.visibility = View.VISIBLE
                    say("Calibrate ho gaya")
                }
            }
            true
        }
        val params = WindowManager.LayoutParams(-1, -1,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT)
        wm.addView(root, params)
    }

    private fun toggle() {
        if (running) {
            running = false; h.removeCallbacks(tickRun); say("Band")
            return
        }
        if (buyX < 0 || sellX < 0) { say("Pehle Calibrate karo"); return }
        if (TapService.inst == null) { say("Accessibility ON karo"); return }
        running = true
        say("Agli candle ka intezar...")
        panel?.visibility = View.GONE
        schedule()
    }

    private fun schedule() {
        val ms = tfSec * 1000L
        h.postDelayed(tickRun, ms - (System.currentTimeMillis() % ms) + 1500)
    }

    private fun tick() {
        if (!running) return
        val bmp = grab()
        val sig = if (bmp != null) analyze(bmp) else null
        when (sig) {
            "UP" -> { TapService.tap(buyX, buyY); say("Signal UP -> Trade lagi (comp ${comp}x)") }
            "DOWN" -> { TapService.tap(sellX, sellY); say("Signal DOWN -> Trade lagi (comp ${comp}x)") }
            else -> say("Signal clear nahi, skip")
        }
        schedule()
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val pl = img.planes[0]
        val bmp = Bitmap.createBitmap(pl.rowStride / pl.pixelStride, hgt, Bitmap.Config.ARGB_8888)
        bmp.copyPixelsFromBuffer(pl.buffer)
        img.close()
        return bmp
    }

    // Chart ke aakhri 5 band candles ka colour dekh kar trend-follow signal
    private fun analyze(b: Bitmap): String? {
        val y0 = (hgt * chartTop).toInt(); val y1 = (hgt * chartBottom).toInt()
        val runs = ArrayList<Char>()
        var cur = ' '
        var x = (w * chartRight).toInt()
        while (x > (w * 0.03f).toInt()) {
            var g = 0; var r = 0
            var y = y0
            while (y < y1) {
                val p = b.getPixel(x, y)
                val rr = Color.red(p); val gg = Color.green(p); val bb = Color.blue(p)
                if (gg > 140 && rr < 110 && bb < 110) g++
                else if (rr > 200 && gg < 130 && bb < 90) r++
                y += 4
            }
            val c = if (g >= 2 && g > r) 'G' else if (r >= 2) 'R' else ' '
            if (c != ' ' && c != cur) runs.add(c)
            cur = c
            x -= 1
        }
        if (runs.size < 6) return null
        val last = runs.subList(1, 6) // run 0 = abhi ban rahi candle, skip
        val gc = last.count { it == 'G' }
        return if (gc >= 3) "UP" else "DOWN"
    }

    override fun onDestroy() {
        h.removeCallbacks(tickRun)
        try { logo?.let { wm.removeView(it) }; panel?.let { wm.removeView(it) } } catch (_: Exception) {}
        vd?.release(); proj?.stop()
        super.onDestroy()
    }
}
