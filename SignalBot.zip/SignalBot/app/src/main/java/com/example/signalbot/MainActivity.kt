package com.example.signalbot

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val req = 1

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        l.addView(TextView(this).apply { text = "Signal Bot\nPehle demo account par test karo."; textSize = 18f })
        fun btn(t: String, f: () -> Unit) { l.addView(Button(this).apply { text = t; setOnClickListener { f() } }) }
        btn("1) Overlay permission") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2) Accessibility ON karo (Signal Bot)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        btn("3) Bot start karo") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Pehle overlay permission do", Toast.LENGTH_LONG).show()
            } else {
                val m = getSystemService(MediaProjectionManager::class.java)
                startActivityForResult(m.createScreenCaptureIntent(), req)
            }
        }
        setContentView(l)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(r: Int, c: Int, d: Intent?) {
        super.onActivityResult(r, c, d)
        if (r == req && c == RESULT_OK && d != null) {
            val i = Intent(this, BotService::class.java).putExtra("code", c).putExtra("data", d)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }
}
